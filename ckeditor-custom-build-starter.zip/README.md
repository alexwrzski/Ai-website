# CKEditor 5 Custom Build Starter (Clean Project)

This is a scaffold for a custom CKEditor 5 build including:
- Placeholder support
- Word Import (Premium plugin - must be added manually after license purchase)
- Token field styling
- Ready for integration with your AI-powered merge translation pipeline

## 📦 Getting Started

1. Clone this folder or unzip it.
2. Run `npm install` (requires Node.js and npm)
3. Add premium plugins (e.g., Word Import) from CKEditor's private NPM registry once licensed.
4. Run the build with `npm run build`
5. Include the built `/build/ckeditor.js` in your frontend

## 📁 Structure
- `/src/ckeditor.js` — Editor entrypoint with plugin imports
- `/src/plugins/` — Custom plugin folder (you can place Token tools here)
- `/build/` — Final build output after `npm run build`

## 🔐 Premium Plugins
After purchasing CKEditor license:
- Login to your CKEditor dashboard
- Get your private NPM token
- Add it to your `.npmrc`:
  ```
  //registry.npmjs.org/:_authToken=YOUR_TOKEN_HERE
  ```
- Then install Word Import, PDF Export, etc.

## 🔄 Updating CKEditor
You can run:
```
npm update
```
…to get the latest compatible version of CKEditor core and plugins. Always check changelogs when upgrading major versions.

## 🤖 AI Integration
Once Word content is loaded into CKEditor, pass the HTML content to your AI translation agent via an API or n8n webhook.

You're ready to build a powerful document editing & automation workflow!
