import ClassicEditorBase from '@ckeditor/ckeditor5-editor-classic/src/classiceditor';

import Essentials from '@ckeditor/ckeditor5-essentials/src/essentials';
import Paragraph from '@ckeditor/ckeditor5-paragraph/src/paragraph';
import Bold from '@ckeditor/ckeditor5-basic-styles/src/bold';
import Italic from '@ckeditor/ckeditor5-basic-styles/src/italic';
import Placeholder from '@ckeditor/ckeditor5-placeholder/src/placeholder';

// TODO: Add WordImport plugin here once licensed
// import WordImport from '@ckeditor/ckeditor5-word-import/src/wordimport';

export default class ClassicEditor extends ClassicEditorBase {}

ClassicEditor.builtinPlugins = [
  Essentials,
  Paragraph,
  Bold,
  Italic,
  Placeholder
  // WordImport
];

ClassicEditor.defaultConfig = {
  toolbar: ['bold', 'italic'],
  placeholderConfig: {
    types: ['aci.firstname', 'aci.lastname', 'loanamount', 'interestrate', 'loanterm']
  },
  language: 'en'
};
