import ClassicEditorBase from '@ckeditor/ckeditor5-editor-classic/src/classiceditor';

import Essentials from '@ckeditor/ckeditor5-essentials/src/essentials';
import Paragraph from '@ckeditor/ckeditor5-paragraph/src/paragraph';
import Bold from '@ckeditor/ckeditor5-basic-styles/src/bold';
import Italic from '@ckeditor/ckeditor5-basic-styles/src/italic';
import Placeholder from '@ckeditor/ckeditor5-placeholder/src/placeholder';
import SmartTokenDropdown from './plugins/SmartTokenDropdown/smarttokendropdown';

export default class ClassicEditor extends ClassicEditorBase {}

ClassicEditor.builtinPlugins = [
  Essentials,
  Paragraph,
  Bold,
  Italic,
  Placeholder,
  SmartTokenDropdown
];

ClassicEditor.defaultConfig = {
  toolbar: ['bold', 'italic', 'smartTokenDropdown'],
  language: 'en'
};
