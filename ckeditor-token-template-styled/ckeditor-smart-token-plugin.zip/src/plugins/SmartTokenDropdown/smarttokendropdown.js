import Plugin from '@ckeditor/ckeditor5-core/src/plugin';
import Model from '@ckeditor/ckeditor5-ui/src/model';
import createDropdown from '@ckeditor/ckeditor5-ui/src/dropdown/utils';
import ListView from '@ckeditor/ckeditor5-ui/src/list/listview';
import ListItemView from '@ckeditor/ckeditor5-ui/src/list/listitemview';
import InputView from '@ckeditor/ckeditor5-ui/src/inputtext/inputview';
import View from '@ckeditor/ckeditor5-ui/src/view';

export default class SmartTokenDropdown extends Plugin {
  async init() {
    const editor = this.editor;
    const locale = editor.locale;
    const tokenEndpoint = 'https://your-api.com/token-list'; // TODO: Replace with your real API

    // Fetch token list from API
    const tokenList = await fetch(tokenEndpoint).then(res => res.json()).catch(() => []);
    editor.config.set('smartTokens', tokenList || []);

    editor.ui.componentFactory.add('smartTokenDropdown', locale => {
      const dropdownView = createDropdown(locale);
      const listView = new ListView(locale);
      const inputView = new InputView(locale);

      dropdownView.buttonView.set({
        label: 'Insert Token',
        tooltip: true,
        withText: true
      });

      // Add searchable input field
      const panelView = new View(locale);
      panelView.setTemplate({
        tag: 'div',
        children: [inputView.element, listView.element],
        attributes: { class: 'ck-smart-token-panel' }
      });

      dropdownView.panelView.children.add(panelView);

      // Populate list view
      const updateList = (filter = '') => {
        listView.items.clear();
        tokenList
          .filter(token => token.label.toLowerCase().includes(filter.toLowerCase()))
          .forEach(token => {
            const itemView = new ListItemView(locale);
            itemView.set({
              label: token.label,
              withText: true,
              tooltip: token.description || ''
            });

            itemView.on('execute', () => {
              editor.model.change(writer => {
                const insertPosition = editor.model.document.selection.getFirstPosition();
                writer.insertText(token.token, insertPosition);
              });
              dropdownView.isOpen = false;
            });

            listView.items.add(itemView);
          });
      };

      inputView.on('input', () => {
        const value = inputView.element.value;
        updateList(value);
      });

      updateList();

      return dropdownView;
    });
  }
}
