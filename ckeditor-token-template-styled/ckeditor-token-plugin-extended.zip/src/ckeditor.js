import ClassicEditorBase from '@ckeditor/ckeditor5-editor-classic/src/classiceditor';

import Essentials from '@ckeditor/ckeditor5-essentials/src/essentials';
import Paragraph from '@ckeditor/ckeditor5-paragraph/src/paragraph';
import Bold from '@ckeditor/ckeditor5-basic-styles/src/bold';
import Italic from '@ckeditor/ckeditor5-basic-styles/src/italic';
import Placeholder from '@ckeditor/ckeditor5-placeholder/src/placeholder';
import TokenDropdown from './plugins/TokenDropdown/tokendropdown';

export default class ClassicEditor extends ClassicEditorBase {}

ClassicEditor.builtinPlugins = [
  Essentials,
  Paragraph,
  Bold,
  Italic,
  Placeholder,
  TokenDropdown
];

ClassicEditor.defaultConfig = {
  toolbar: ['bold', 'italic', 'tokenDropdown'],
  placeholderConfig: {
    types: ['aci.firstname', 'aci.lastname', 'loanamount', 'interestrate', 'loanterm']
  },
  language: 'en'
};
