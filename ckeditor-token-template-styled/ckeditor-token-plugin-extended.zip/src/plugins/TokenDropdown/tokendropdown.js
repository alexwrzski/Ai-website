import Plugin from '@ckeditor/ckeditor5-core/src/plugin';
import Model from '@ckeditor/ckeditor5-ui/src/model';
import createDropdown from '@ckeditor/ckeditor5-ui/src/dropdown/utils';
import SplitButtonView from '@ckeditor/ckeditor5-ui/src/dropdown/button/splitbuttonview';

export default class TokenDropdown extends Plugin {
  init() {
    const editor = this.editor;
    const tokenList = [
      { label: 'First Name', token: '%%aci.firstname%%' },
      { label: 'Last Name', token: '%%aci.lastname%%' },
      { label: 'Loan Amount', token: '%%loanamount%%' },
      { label: 'Interest Rate', token: '%%interestrate%%' },
      { label: 'Loan Term', token: '%%loanterm%%' }
    ];

    editor.ui.componentFactory.add('tokenDropdown', locale => {
      const dropdownView = createDropdown(locale);
      const buttonModel = new Model({
        label: 'Insert Token',
        withText: true,
        tooltip: true
      });

      dropdownView.buttonView.set(buttonModel);

      const listItems = tokenList.map(item => {
        const itemModel = new Model({
          label: item.label,
          withText: true
        });

        itemModel.on('execute', () => {
          editor.model.change(writer => {
            const insertPosition = editor.model.document.selection.getFirstPosition();
            writer.insertText(item.token, insertPosition);
          });
        });

        return itemModel;
      });

      dropdownView.listView.items.addMany(listItems);

      return dropdownView;
    });
  }
}
